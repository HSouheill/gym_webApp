<?php
session_start();

if (!isset($_SESSION['email'])) {
  header('Location: http://localhost/gym-project-php/login.php');
  exit;
}

require "connection.php";

$stmt = $conn->prepare("SELECT id, name, email, profile_picture FROM users WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$user_id = $user['id'];
$name = $user['name'];
$email = $user['email'];
$profile_picture = $user['profile_picture'];

$stmt = $conn->prepare("SELECT posts.post_id, posts.title, posts.images, users.name AS user_name, users.profile_picture AS user_profile_picture FROM posts INNER JOIN users ON posts.user_id = users.id WHERE users.email = ? ORDER BY posts.timestamp DESC");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$result = $stmt->get_result();

$posts = [];
while ($row = $result->fetch_assoc()) {
  $posts[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['delete_post'])) {
    $post_id_to_delete = $_POST['delete_post_id'];

    // Validate if the post belongs to the logged-in user before deleting
    $validate_stmt = $conn->prepare("SELECT user_id FROM posts WHERE post_id = ?");
    $validate_stmt->bind_param("i", $post_id_to_delete);
    $validate_stmt->execute();
    $validate_result = $validate_stmt->get_result();
    $validate_row = $validate_result->fetch_assoc();
    $validate_stmt->close();

    if ($validate_row['user_id'] == $user_id) {
      // Delete the post
      $delete_stmt = $conn->prepare("DELETE FROM posts WHERE post_id = ?");
      $delete_stmt->bind_param("i", $post_id_to_delete);
      $delete_stmt->execute();
      $delete_stmt->close();
    }
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log-out'])) {
  session_destroy();
  setcookie('login_preferences', '', time() - 3600, '/');
  header('Location: http://localhost/gym-project-php/login.php');
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Posts</title>
  <link rel="stylesheet" href="MyPosts.css">
</head>
<body>
<header>

<nav class="navbar">
  <div class="nav-left">
  <a href="#" onclick="event.preventDefault();" id="burger">&#9776;</a>
  <a href="#" onclick="event.preventDefault();" id="exit"> &#10005;</a>
  
 
  </div>
  <h2>Fitness</h2>  
</nav>
</header>

  <div class="sidebar">
    <div class="side-info">
    <?php if (!empty($profile_picture)) : ?>
          <img src="<?php echo $profile_picture; ?>">
        <?php endif; ?>
        <h2><?php echo $name; ?></h2>
        <h3><?php echo $email; ?></h3>
    </div>

    <div class="actions">
     <form action="" method="POST">
     <div id="home"><a  href="home.php">Home Page</a></div>
     <div id="setting"><a href="editprofile.php">Edit Profile</a></div>
     <button type="submit" id="delete"  name="supplies">Supplies</button>
     <button type="submit" id="log-out" name="log-out">Log Out</button>
     </form>
    </div>
  </div>

  <div class="main-page">
    <?php foreach ($posts as $post) : ?>
      <div class="feed-box">
        <div class="profile">
          <?php if (!empty($post['user_profile_picture'])) : ?>
            <img class="prof-images" src="<?php echo $post['user_profile_picture']; ?>" >
          <?php endif; ?>
          <div class="prof-name"><h2><?php echo $post['user_name']; ?></h2></div>
          <form action="" method="POST">
            <input type="hidden" name="delete_post_id" value="<?php echo $post['post_id']; ?>">
            <button type="submit" class="delete-button" name="delete_post">&times;</button>
          </form>
        </div>
        <div class="expression">
          <h3><?php echo $post['title']; ?></h3>
      
        </div>
        <div class="content-img">
          <?php if (!empty($post['images'])) : ?>
            <img class="images" src="<?php echo $post['images']; ?>">
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
  var burger = document.getElementById("burger");
  var exit = document.getElementById("exit");
  var sidebar = document.querySelector(".sidebar");

  burger.addEventListener("click", function() {
    sidebar.style.left = "0";
    burger.style.display = "none";
    exit.style.display = "block";
  });

  exit.addEventListener("click", function() {
    sidebar.style.left = "-250px";
    burger.style.display = "block";
    exit.style.display = "none";
  });
});

  </script>
</body>
</html>
